package com.app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.app.model.Quiz;
import com.app.service.QuizService;

@Component
public class DBInitializer implements CommandLineRunner{
	private QuizService service;
	public DBInitializer(QuizService service) {
		this.service=service;
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Quiz quiz1 =new Quiz("Which animal is known as the ‘Ship of the Desert?","Camel" ,"Tiger","Lion","Elephant",1);
		Quiz quiz2 =new Quiz("Which animal is called King of Jungle?","Tiger","Lion","Elephant","Dinosaur",2);
		Quiz quiz3 = new Quiz("How many finals has Mahendra Singh Dhoni played in the IPL?","6","3"," 7"," 8",3);
		Quiz quiz4=new Quiz( "Which cricketer has scored the fastest hundred in the IPL?", "Virat Kohli", "Chris Gayle", "MSD", " Raina", 2);
		Quiz quiz5=new Quiz( "Who is the current head coach of the Delhi Daredevils?","Virender Sehwag", "Rahul Dravid", "Pravin Amre", "Ricky Ponting", 4);
		Quiz quiz6=new Quiz( "Why was the second season of the IPL moved to South Africa?", "Better facilities", "Indian's National Election", "Weather issues","Sponsor Demand", 2);
		Quiz quiz7=new Quiz("Who scored the first century in the IPL in 2008?", "Dhawan", " Dhoni ", "Raina", "Brendon McCullum", 4);
		Quiz quiz8=new Quiz("Which Bowler has taken most number of wickets?", "Ashwin ravichandran", "Munaf Patel", "Yousuf Pathan", "Lashith Malinga", 4);
		Quiz quiz9=new Quiz(" which player got two consecutive golden bats at ICC Champions Trophy ?  ", "Dhoni", "Warner", "Virat", "Dhawan", 4);
		Quiz quiz10=new Quiz("which company sponsour IPL 2020 ?", "Vivo", "Dream 11", "Mpl", "Udemy", 2);
		this.service.saveQuiz(quiz1);
		this.service.saveQuiz(quiz2);
		this.service.saveQuiz(quiz3);
		this.service.saveQuiz(quiz4);
		this.service.saveQuiz(quiz5);
		this.service.saveQuiz(quiz6);
		this.service.saveQuiz(quiz7);
		this.service.saveQuiz(quiz8);
		this.service.saveQuiz(quiz9);
		this.service.saveQuiz(quiz10);
		System.out.println("Database has been initialized");
		
	}

}
