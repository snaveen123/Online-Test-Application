package com.quizapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
